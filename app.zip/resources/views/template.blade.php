@extends('layout.main')

@section('title', 'Admin || Template')

@section('content')
    <div class="container-fluid p-0">

        <h1>Template</h1>

    </div>
@endsection
