@extends('layout.main')

@section('title', 'Admin Dashboard')

@section('content')
    <div class="container-fluid p-0">

        <h1>Dashboard</h1>

    </div>
@endsection
