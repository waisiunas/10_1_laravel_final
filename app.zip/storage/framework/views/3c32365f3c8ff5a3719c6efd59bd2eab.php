<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-12">
                <div class="h1 text-center">Migicians</div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\Magicians\Desktop\laravel\prepare\resources\views/partials/footer.blade.php ENDPATH**/ ?>