<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(Session::get('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php elseif(Session::has('failure')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(Session::get('failure')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Magicians\Desktop\laravel\prepare\resources\views/partials/flash-messages.blade.php ENDPATH**/ ?>