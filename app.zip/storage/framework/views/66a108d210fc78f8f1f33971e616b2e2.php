<?php $__env->startSection('title', 'Admin || Subjects'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">

        <div class="row">
            <div class="col">
                <h1>Subjects</h1>
            </div>
            <div class="col text-end">
                <a href="<?php echo e(route('admin.subject.create')); ?>" class="btn btn-outline-primary">Add Subject</a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <?php echo $__env->make('partials.flash-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php if(count($subjects) > 0): ?>
                    <table class="table table-bordered m-0">
                        <thead>
                            <tr>
                                <th>Sr. No.</th>
                                <th>Subject Name</th>
                                <th>Subject Slug</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($subject->name); ?></td>
                                    <td><?php echo e($subject->slug); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.subject.edit', $subject)); ?>"
                                            class="btn btn-primary">Edit</a>
                                        <a href="<?php echo e(route('admin.subject.delete', $subject)); ?>"
                                            class="btn btn-danger">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="alert alert-danger m-0">No record found!</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Magicians\Desktop\laravel\prepare\resources\views/admin/subject/index.blade.php ENDPATH**/ ?>