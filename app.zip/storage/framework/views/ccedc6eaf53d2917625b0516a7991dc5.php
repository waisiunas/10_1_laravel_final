<?php $__env->startSection('title', 'Admin || Questions'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">

        <div class="row">
            <div class="col">
                <h1>Questions</h1>
            </div>
            <div class="col text-end">
                <a href="<?php echo e(route('admin.question.create')); ?>" class="btn btn-outline-primary">Add Question</a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <?php echo $__env->make('partials.flash-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php if(count($questions) > 0): ?>
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-9">
                                        <h5><?php echo e($loop->iteration); ?>. <?php echo e($question->text); ?></h5>
                                        <ul>
                                            <?php $__currentLoopData = $question->choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($choice->is_correct == 1): ?>
                                                    <li><?php echo e($choice->text); ?> (Correct)</li>
                                                <?php else: ?>
                                                    <li><?php echo e($choice->text); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <div class="col-3">
                                        <a href="<?php echo e(route('admin.question.edit', $question)); ?>" class="btn btn-primary">Edit</a>
                                        <a href="<?php echo e(route('admin.question.delete', $question)); ?>" class="btn btn-danger">Delete</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="alert alert-danger m-0">No record found!</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Magicians\Desktop\laravel\prepare\resources\views/admin/question/index.blade.php ENDPATH**/ ?>